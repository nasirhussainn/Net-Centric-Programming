public class NetworkClientTest {
    public static void main(String[] args) {
        String host = "localhost";
        if (args.length > 0)
            host = args[0];
        int port = 8088;

        if (args.length > 1)
            port = Integer.parseInt(args[1]);
        System.out.println(host);
        System.out.println(port);
        NetworkClient nwClient = new NetworkClient(host, port);
        nwClient.connect();
    }
}
