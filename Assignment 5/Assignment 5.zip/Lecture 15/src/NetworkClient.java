import java.net.*;
import java.io.*;
import java.text.ParseException;

public class NetworkClient {
    protected String host;
    protected int port;
    public NetworkClient(String host, int port) {
        this.host = host; 	this.port = port; }
    public String getHost() { 	return host; }
    public int getPort() { 	return port; }
    public void connect() {
        try {
            Socket client = new Socket(host, port);
            handleConnection(client);
        } catch(UnknownHostException uhe) {
            System.out.println("Unknown host: " + host);  	uhe.printStackTrace();
        } catch(IOException ioe) {
            System.out.println("IOException: " + ioe);  ioe.printStackTrace();
        }}
    protected void handleConnection(Socket client)  throws IOException {
        PrintWriter out =  SocketUtil.getPrintWriter(client);
        BufferedReader in =  SocketUtil.getBufferedReader(client);
        System.out.println("Generic Network Client:\n" +  "Made connection to " + host + " and got '" + in.readLine() + "' in response");
        client.close();
    }
    public static void main (String arg[]) throws IOException, ParseException {
        Daytime testtime= new Daytime();
        System.out.println(testtime.getDateFromNetwork());
    }
}

